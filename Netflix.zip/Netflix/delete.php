<link rel="stylesheet" href="styles.css">
<html>
    <body>
<style>
    body{
    background-color: black;
    color: white;   
}
</style>
<?php
$username='';
$email='';
$password='';
$confirm_password='';
if(isset($_POST['username'])|| isset($_POST['email'])||isset($_POST['password'])||isset($_POST['confirm_password'])){

$username = $_POST['username'];
$email = $_POST['email'];
$password = $_POST['password']; // Hash the password before storing
$confirm_password = $_POST['confirm_password'];
}
// Database connection parameters
$servername = "localhost"; // Change this if your database is on a different server
$name = "root";
$pass = "";
$database = "crud";

// Create connection
$conn = new mysqli($servername, $name, $pass, $database);

// Check connection
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// SQL query to insert data into the users table
$sql = "DELETE FROM users WHERE username='malaika'";


if ($conn->query($sql) === TRUE) {
    echo "One record deleted successfully!";
} else {
    echo "Error: " . $sql . "<br>" . $conn->error;
}

// Close the database connection
$conn->close();
header("Location:show.php");
?>
<br>
<button type="submit"  class="btn btn-primary btn-block btn-lg" ><a href="index.html" class="ok">Ok!</a> </button>
        
</body>
</html>