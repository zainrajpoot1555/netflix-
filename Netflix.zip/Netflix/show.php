<?php
$con=mysqli_connect('localhost','root','','crud');
$res=mysqli_query($con,"Select * from users");
?>
<html>
<center>
    <style>
          body{
    background-color: black;
    color: white;   
}
.bb{
    padding:10px 20px 10px 20px;
    margin: 10px; 
    background-color:grey;
}
.bb1{
    padding:10px 20px 10px 20px;
    margin: 10px; 
    background-color:red;
}
.bb:hover,
.bb1:hover{
   opacity: 0.10;
}
a{
    text-decoration:none;
    color:white;
}
    </style>
    <body>
        <h1>SIGN UP FORM DATA</h1>
<table border='1'>
    <tr>
        <th>Username</th>
        <th>Email</th>
        <th>Password</th>
        <th>Confirm password</th>
    </tr>
    <?php while($row=mysqli_fetch_assoc($res)) { ?>
    <tr>
        <td><?php echo $row['username']?></td>
        <td><?php echo $row['email']?></td>
        <td><?php echo $row['password']?></td>
        <td><?php echo $row['confirm_password']?></td>
          </tr>
    <?php } ?>
</table>
<button class="bb"><b><a href="update.php">Update</a></b></button>
<button class="bb1"><b><a href="delete.php">Delete</a></b></button>     
<button class="bb"><b><a href="index.html">Go Back</a></b></button>
  
</body>
</center>
</html>